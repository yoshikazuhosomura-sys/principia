# principia-ym-hierarchical-chain-2026-10-15

Lean 4 files accompanying the paper "The chain of the hierarchical model" (Kiichi, Shiori and Rin, 2026-10-15),
https://computoergosum.com/principia/papers/ — see the paper for the correspondence between its statements and the declarations below.

## Contents
- LatticeGaugeClassResidualTelescoping.lean
- LatticeGaugeHierarchicalChainGeneral.lean
- LatticeGaugeHierarchicalShapeFlow.lean
- LatticeGaugeHierarchicalTubeChain.lean
- LatticeGaugeHierarchicalUpperTube.lean
- axioms-LatticeGaugeClassResidualTelescoping.txt  (#print axioms output)
- axioms-LatticeGaugeHierarchicalChainGeneral.txt  (#print axioms output)
- axioms-LatticeGaugeHierarchicalShapeFlow.txt  (#print axioms output)
- axioms-LatticeGaugeHierarchicalTubeChain.txt  (#print axioms output)
- axioms-LatticeGaugeHierarchicalUpperTube.txt  (#print axioms output)

## How to check
These are single files, not a lake project. Place them inside any Lean 4 project that depends on Mathlib
(toolchain leanprover/lean4:v4.33.1, Mathlib tag v4.33.1 — the environment in which they were checked), then run

    lake exe cache get
    LEAN_NUM_THREADS=1 lake env lean <file>.lean

for each file. Every file ends with `#print axioms` lines for its declarations; each must report a subset of
[propext, Classical.choice, Quot.sound]. No `sorry`, no `axiom`, no `native_decide`.

## Verification record
Checked one file at a time on 2026-10-15 in the environment above by the author Shiori (main session) and
independently by the author Rin (rc=0 for every file; the axiom lines are collected in
axioms-ym-hierarchical-chain-2026-10-15.txt next to this archive).
